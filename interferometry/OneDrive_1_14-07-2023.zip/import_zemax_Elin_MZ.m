
function import_zemax_Elin_MZ

% this is for a 1D row of numbers from zemax to fourier transform it

f = fopen('test1.txt', 'rt');
%C=textscan(f,'','HeaderLines',24, 'emptyvalue',nan,'collectoutput',1);  % 26 for row, 24 for array
C = textscan(f,'%f%f','HeaderLines',26);  % 26 for us
fclose(f);
theta=0.65%0.41%

sin_theta_incident = sin(theta*pi/180);

dx = 500%2.2%500% in um this is the spacing between pixels - Thz is 0.5mm (500um)

A=cell2mat(C);
A=A;
np=size(A,1);
x=A(:,2);
shave=3;
x=x(shave:np);
y=(shave:np);   % y is just in points


subplot(2,1,1)
set(gcf, 'color', 'white')
hold on;
ycm=y*dx*1e-4;  % the y axis in cm
plot(ycm,x)
xlabel('length along detector (cm)');
ylabel('Amplitude (arb.)');
In=([y(1,:)',x])';
fileID = fopen('interferogram.txt','w');
fprintf(fileID,'%6.9f %12.9f\n',In);
fclose(fileID);

[spectrum, kd] = single_sided_ft(x, 1./dx);  % function FFT across the detector array

um1=(kd/(2*sin_theta_incident));  % normal

um=1./um1;

%---- fit the experimental peaks  
 %  [pks,locs,w,p] = findpeaks(Ysig,'MinPeakHeight',7.5,'WidthReference','halfheight'); % 'WidthReference','halfheight'
    
    I3 = find(um > 90); % this is the range where the peak is
    I3 = max(I3);
    I4 = find(um > 80); % this is the range where the peak is
    I4 = max(I4);
    sigum=um(I3:I4)';
    sigB1=spectrum(I3:I4)';
    %sigB1=sigB1/max(sigB1);
    Signalfit=[sigum;sigB1];
    

   
   %[FitResults,GOF,baseline,coeff,residual,x,y]=peakfit(Signalfit,0.583,0.05,1,1,0,1,[0.580 0.004],3); %  FitResults: a table of model peak parameters, one row for each peak,
%    listing Peak number, Peak position, Height, Width, and Peak area. peakfit(signal,center,window,NumPeaks,peakshape,extra,NumTrials,start,autozero)- from peakfit.m. NEED
%    output: Peak number  Peak position   Height     Width      Peak area
%    TO CHANGE
%FitResults


T=spectrum(:,1)';
subplot(2,1,2)
set(gcf, 'color', 'white')
hold on;
plot(um,T)
axis([0 160 0 10e-6]);
xlabel('wavelength (um)');
ylabel('Amplitude (arb.)');

B95 = [um T'];
fileID = fopen('outputwave.txt','w');
fprintf(fileID,'%6s %12s\n','kd','spectrum');
fprintf(fileID,'%6.9f %12.9f\n',B95');
fclose(fileID);

function [X, f] = single_sided_ft(x, Fs)
 % Assumes x is an N x 1 column vector
 % and Fs is the sampling rate.
 
 N = size(x,1);
 NFFT = 2^nextpow2(N); % Next power of 2 from length of y
 X=fft(x, NFFT)/N;
 f = Fs/2*linspace(0,1,NFFT/2+1);  % do half of the spectrum only
 f=f';
 X=2*abs(X(1:NFFT/2+1));
 


