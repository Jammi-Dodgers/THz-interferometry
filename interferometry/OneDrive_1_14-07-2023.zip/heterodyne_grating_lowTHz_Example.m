function heterodyne_grating_milimeter
%------------------------------------------------------------------
% Grid parameters  INPUT
%------------------------------------------------------------------
    
% NOTE THAT THE HETERODYNE FREQUENCY IF HETEREODYNING UP IS um1=(kd/(2*sin_theta_incident))-1/heterodyne_wavelength

xmax = 5100*100; nx = 2^15;  % xmax = 5100; nx = 2^15;  WATCH OUT xmax goes up with pixelsize xmax = 5100*100; nx = 2^16;   
theta=4;% Angle of incidence (degrees) THIS IS THE ANGLE BETWEEN ONE BEAM AND THE NORMAL.
line_centre_THz =  0.25 ;%
line_centre = (1./line_centre_THz)*299.792458; %  line centre in um 
optic_dia=26;% diameter of optic in cm have put to be massive

sin_theta_incident = sin(theta*pi/180);
freqpos_nograting=abs(2*(1/line_centre)*sin_theta_incident);
spacing=line_centre/(2*sin_theta_incident)

%------------------------------------------------------------------
% Detector parameters INPUT
%------------------------------------------------------------------
pixelsize=500;
z0 = 0; np = 150 % BE CAREFUL AT LARGE ANGLES THIS NEEDS TO BE ZERO!
x0 = (pixelsize*np)/2; x1 = -x0;  %
Nwav=freqpos_nograting*(pixelsize*np) % Number of wavelengths on detector assuming optic_dia large enough
pathdiff=Nwav*line_centre; % the max optical path difference um
ResPower= (pathdiff*2)/line_centre;  % Resolving Power of the setup

%------------------------------------------------------------------
% Peak parameters INPUT
%------------------------------------------------------------------
FWHM=200; 
%------------------------------------------------------------------

% Grids
x = linspace(-xmax, xmax, nx);
dxg = x(2) - x(1);
kx = linspace(-pi, pi, nx)./dxg;

grat=0;
e0 = ones(size(x));
line_colour = 'g';   

nl = 150;%
line_width=FWHM/2.3548; % the standard deviation for the Gaussian lineshape
lambda = line_centre + 0.5*line_width*linspace(-10,10, nl); 
ii = lambda > 0;  
size(lambda)
lambda = lambda(ii);
spec = gaussian_line(lambda, line_centre, line_width);

%----------------
% Peak in matlab graph
%----------------
lambdaGHz= (1./(lambda/299.7924))*1e3;
figure(2)
set(gcf, 'color', 'white')
hold on;
plot(lambdaGHz, spec, line_colour);
set(gcf, 'color', 'white')
xlabel('Input frequencies (GHz)');
ylabel('Amplitude (arb.)');

%----------------
% Peak in write to .txt file
%----------------
B45=[lambdaGHz;spec];
fileID = fopen('peaksinput.txt','w');
fprintf(fileID,'%6s %12s\n','lambdaGHz','spec');
fprintf(fileID,'%6.9f %12.9f\n',B45);
fclose(fileID);
%------------------------------------------------------------------
delay_x=0/(sin_theta_incident);
intensity = zeros(1, nx);
for ii = 1:nl-40    
    k = 2*pi/lambda(ii);   
    beam = e0.*exp(1i*k.*sin_theta_incident.*x);
    delayed_beam = e0.*exp(1i*k.*sin_theta_incident.*(x+delay_x));
    delayed_beam = fliplr(delayed_beam);
    e = beam + delayed_beam;
    intensity = intensity + abs(e).^2.*spec(ii);  
end

%------------------------------------------------------------------
%---- figures and write out
%------------------------------------------------------------------
% Detector
detector_points = linspace(x1, x0, np);
signal = detector_binning(x, detector_points, intensity);
signal = signal - mean(signal);

% Single-sided FT
dx = abs(detector_points(2) - detector_points(1)); % this should be equal to pixelsize averaged over points
[spectrum, kd] = single_sided_ft(signal', 1./dx);  % function FFT across the detector array
nyquist = max(kd)/2

theta_max_nograting=asin((nyquist*line_centre)*0.5)*(180/pi) % correct

um1=(kd/(2*sin_theta_incident)); minwave=1/(nyquist/(2*sin_theta_incident)); maxwave=1/(0.5e-4/(2*sin_theta_incident))                 

um=1./um1;

%---- figures and write out

%----------------
% Output interferogram and frequency spectrum in a matlab graph
%----------------
figure(1)
set(gcf, 'color', 'white')
GHz = (1./um)*299.792458*1e3;

subplot(2,1,1)
hold on;
plot(detector_points*1e-4, signal);
axis([min(detector_points*1e-4) max(detector_points*1e-4) -100 100])
detector_pointswrite=detector_points(1,:)*1e-4;
signalwrite=signal(1,:);
xlabel('Output interferogram - Length along detector (cm)');
ylabel('Intensity (arb.)');

subplot(2,1,2)
hold on;
plot(GHz, spectrum, 'c');  % 
axis([(line_centre_THz*1000-200) (line_centre_THz*1000+200) 0 100])
set(gcf, 'color', 'white')
xlabel('Output frequency (GHz)');
ylabel('Amplitude (arb.)');

%----------------
% Output interferogram and frequency spectrum in a .txt file
%----------------

B2 = [detector_pointswrite;signalwrite];
fileID = fopen('fft.txt','w');
fprintf(fileID,'%6s %12s\n','kd','spectrum');
fprintf(fileID,'%6.9f %12.9f\n',B2);
fclose(fileID);

B95 = [GHz(:,1) spectrum(:,1)];
fileID = fopen('outputwave.txt','w');
fprintf(fileID,'%6s %12s\n','kd','spectrum');
fprintf(fileID,'%6.9f %12.9f\n',B95');
fclose(fileID);

%---
%-------------------------------------------------------- functions

function binMean = detector_binning(x, bins, signal)

numBins = length(bins);
binEdges = linspace(min(bins), max(bins), numBins+1);
[h, whichBin] = histc(x, binEdges);
binMean = zeros(1, numBins);
for i = 1:numBins
    flagBinMembers = (whichBin == i);
    binMembers = signal(flagBinMembers);
    binMean(i) = mean(binMembers);
end


function e = grating(x, d)
% Arbitrary orders
q = [2,1,0,-1,-2]; %cq = ones(size(q)); this is the old code for cq
%cq=[0.05,0.25,0.25,0.25,0.05];
cq=[0.0,0.5,0.0,0.5,0.0]; % BEWARE THE FLIPPING PROCESS MEANS THAT ONLY   cq=[0.05,0.25,0.25,0.25,0.05]
%A SYMMETRICAL GRATING WILL WORK
cq = cq./sum(cq.^2);    % normalise
e = arbitrary_phase_grating(x, q, cq, d);

%e = phase_grating(x, d, 1, 0); 

% Square wave
%e = tophat_grating(x, d, d/2);

% Phase
%e = phase_grating(x, d, 1, 0);  I was using phase grating like this

% Amplitude
%e = amplitude_grating(x, d, 2, 0);
%------------------------------------------------------------------
function s = gaussian_line(x, x0g, dx)
s = exp(-(x-x0g).^2./(2*dx^2));

function e = amplitude_grating(x, d, contrast, phi)
e = 0.5*(1 + contrast*cos(2*pi*x/d + phi));

function e = phase_grating(x, d, contrast, phi)
e = ones(size(x));
e = e.* exp(1i*contrast/2*sin(2*pi*x/d + phi));

function e = tophat_grating(x, d, w)
e = zeros(size(x));
ii = mod(x + w/2, d) < w;
e(ii) = 1;

function e = arbitrary_phase_grating(x, q, cq, d)
e = cq*exp(1i*2*pi*q'*x/d);
%e = cq * exp(q'*1i*sin(2*pi*x/d));
function e = square_aperture(e, x, xmin, xmax)
ii = xmin < x & x < xmax;
e(~ii) = 0;

function e = propagate_plane_waves(e, propagator)
f = fftshift(fft(e));   % FT and put k=0 in centre 
f = f .* propagator;    % Free space propagation
e = ifft(ifftshift(f)); % Inverse shift and FT


function [X, f] = single_sided_ft(x, Fs)
 % Assumes x is an N x 1 column vector
 % and Fs is the sampling rate.
 
 N = size(x,1);
 NFFT = 2^nextpow2(N); % Next power of 2 from length of y
 X=fft(x, NFFT)/N;
 f = Fs/2*linspace(0,1,NFFT/2+1);  % do half of the spectrum only
 f=f';
 X=2*abs(X(1:NFFT/2+1));
 
 %}
 %{
  dF = Fs/N;
  f = dF*(0:N/2-1)';
 X = fft(x)/N;
 X = X(1:floor(N/2));
 X(2:end) = 2*X(2:end);
 X = abs(X);
%}

 %---- fit the experimental peaks  
 %   I3 = find(um > 0.625);
 %   I3 = max(I3);
 %   I4 = find(um > 0.45);
 %   I4 = max(I4);
 %   sigum=um(I3:I4)';
 %   spectrumf=spectrum(I3:I4)';
 %   spectrumf=spectrumf/max(spectrumf);
 %   Signalfit=[sigum;spectrumf];

 %   [FitResults,GOF,baseline,coeff,residual,xi,yi]=peakfit(Signalfit,0.578,0.008,2); %  FitResults: a table of model peak parameters, one row for each peak,
%    listing Peak number, Peak position, Height, Width, and Peak area.
%FitResults 
 %    fitfromprog=[xi;yi(1,:)]; % yi(2,:)
   %  fitfromprog = [sigum;spectrumf];
 %  fileID = fopen('fit.txt','w');
 %   fprintf(fileID,'%6.9f %12.9f\n',fitfromprog);
  %  fclose(fileID);

%----
 
%Lenzer_gamma=atan(2*tan_theta_incident)*(180/pi);
%Lenzer_R=(optic_dia*1e-2*sin(Lenzer_gamma*pi/180))/(line_centre*1e-6);
%resolutionLenzer=line_centre/Lenzer_R;

%maxrange= (d^2*sin(2*theta*pi/180))/(2*pixelsize); % from Lenzer paper opt express 24, 1829
%gamma_E_tilt=atan(2*tan_theta_incident)*(180/pi);
%ResPower3=(optic_dia*1e4*sin(gamma_E_tilt*(pi/180)))/heterodyne_wavelength;
%ResPower4=N*cos(gamma_E_tilt*(pi/180));
%resolution2=line_centre/ResPower4;
%resolution2/resolution;
%ResPower2=(4*optic_dia*1e4)/(d*cos_theta_incident)  % from Matthias Lezner paper
%minwave=1/(0.00113591974431809/(2*sin_theta_incident));
%line_centre=0.546;
%heterodyne_wavelength=0.605;
%Nwav=830%756.2876;
%ResPowerBarnes= line_centre/(line_centre^2/(heterodyne_wavelength*Nwav));          % Barnes paper - resolution calculated
%ResPowernograt=line_centre/(line_centre^2/((heterodyne_wavelength-line_centre)*Nwav));  % Barnes paper
%resolutionBarnes= line_centre/ ResPowerBarnes;       % therefore the resolution of the setup in um DONT USE THIS
%enhancement=ResPowerBarnes/ResPowernograt % seems to be correct ...
%freespecrangeBarnes= heterodyne_wavelength/(1+(np/(2*Nwav)));%-heterodyne_wavelength     % Barnes paper - need to put in HIGHEST freq if looking at range
%freespecrangeBarnes= (605/(1+80*(512/(2))))